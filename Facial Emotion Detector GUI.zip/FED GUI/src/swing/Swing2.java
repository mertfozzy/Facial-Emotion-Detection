package swing;

public interface Swing2 {

}
